puppet-clamav

# Support
Nathan Valentine - nathan@puppetlabs.com|nrvale0@gmail.com

# License
Apache 2.0

